import CreativeEditorSDK, { type AssetSource, type AssetDefinition, type AssetQueryData, type AssetsQueryResult, type AssetResult, type CompleteAssetResult } from "@cesdk/cesdk-js";

export const findAssets = async (_query: AssetQueryData): Promise<AssetsQueryResult> => {

    const exampleAsset: AssetResult = {
        id: "SomeId",
        locale: 'en',
        label: "",
        tags: [],
        meta: {
            mimeType: 'image/jpeg',
            uri: '',
            thumbUri: ''
        },
        credits: {
            name: 'IMG.LY',
            url: 'https://img.ly'
        },
        license: {
            name: 'MIT'
        }
    }

    const assets: AssetResult[] = [exampleAsset]
    const assetsResult: AssetsQueryResult = {
        assets: assets,
        total: assets.length,
        currentPage: 0,
        nextPage: 0
    }

    return Promise.resolve(assetsResult);
};


export const registerComponentAssetLibrary = (cesdk: CreativeEditorSDK) => {
    const source: AssetSource = {
        id: 'imgly.components',
        findAssets: findAssets,
        // canManageAssets: true,
        // @ts-ignore
        canAdd: true,
        canRemove: true,
        credits: {
            name: 'IMG.LY',
            url: 'https://img.ly'
        },
        license: {
            name: 'MIT'
        },
        applyAsset: async (asset: CompleteAssetResult): Promise<number | undefined> => {
            return undefined
        },
        applyAssetToBlock: (asset: CompleteAssetResult, block: number): Promise<void> => {
            return Promise.resolve()
        },

        addAsset: (asset: AssetDefinition) => { },

        removeAsset: (assetId: string) => {},
        getSupportedMimeTypes: () => {
            return ['image/jpeg', 'image/png']
        }
    };
    cesdk.engine.asset.addSource(source);
}
