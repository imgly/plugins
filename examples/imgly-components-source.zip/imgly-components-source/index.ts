import type CreativeEditorSDK from '@cesdk/cesdk-js';
import {registerComponentAssetLibrary} from './assets/components'

const Manifest = {
    id: 'imgly/plugin-commands-polyfill',
    publisher: 'img.ly GmbH',
    contributes: {
        commands: {
            "assets": {

            }
        }
    }
};


export interface PluginConfiguration {
    // uploader ? 
}

export { Manifest };

export default () => {
    return {
        ...Manifest,
        initializeUserInterface({ cesdk }: { cesdk: CreativeEditorSDK }) {
            registerComponentAssetLibrary(cesdk)
            
        }
    };
};

